| Macro-F1 (%) | BNCI | UCL | EEGET |
|---|---|---|---|
| Residual only | 62.74 ± 1.10 | 47.28 ± 2.72 | 83.63 ± 3.77 |
| Residual only, parameter-matched | 64.27 ± 1.06 | 45.10 ± 5.72 | 87.78 ± 5.97 |
| Quantum only | 63.32 ± 1.53 | 53.19 ± 3.48 | 84.46 ± 9.36 |

Each entry is Macro-F1 (%) mean ± sample SD (ddof=1) over seeds 11, 22, 33 on fold 0.
BNCI/UCL each test one participant; EEGET tests one ALS participant plus its paired control.
† Uses unlabeled held-out trials. All checkpoint and threshold selection uses source validation only.
MAtt, SPDNet and TSMNet are reimplementations adapted to these datasets and the common trainer.
SPDIM-style adapts only the tangent-space SPD bias by fixed-step information maximization.
SD measures variation across seeds on this fold, not variation across participants.

UCL recovery: trials shorter than the configured two-second analysis window were excluded by a fixed sample-length rule. Counts by participant/class and all excluded trial IDs are saved under audit/UCL_eligibility_counts.csv and audit/UCL_excluded_short_trials.csv. BNCI and EEGET values reuse the original saved predictions; these models were not retrained.

EA + TS-LR: the original OAS/Riemannian pipeline is retained when numerically valid. On a numerical SPD failure, covariance eigenvalues are floored at 1e-6 times the larger of the trial maximum eigenvalue and the median source-training average variance. C and the decision threshold still use source validation only. Activation is recorded in each repaired result.
