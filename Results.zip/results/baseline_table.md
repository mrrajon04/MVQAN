| Macro-F1 (%) | BNCI | UCL | EEGET |
|---|---|---|---|
| LaBraM (fine-tuned) | 65.38 ± 1.89 | 49.61 ± 2.55 | 69.96 ± 2.60 |
| CBraMod (fine-tuned) | 70.08 ± 3.23 | 39.96 ± 3.43 | 92.89 ± 2.98 |
| REVE (fine-tuned) | 67.01 ± 0.84 | 47.90 ± 2.25 | 89.12 ± 5.27 |
| MAtt | 52.16 ± 1.93 | 49.10 ± 5.11 | 86.38 ± 5.05 |
| SPDNet | 46.02 ± 0.70 | 48.48 ± 4.34 | 78.89 ± 10.15 |
| TSMNet (SPDDSMBN)† | 54.06 ± 0.59 | 51.70 ± 0.68 | 46.41 ± 1.35 |
| SPDIM-style (IM-adapted SPD bias)† | 45.45 ± 0.00 | 44.94 ± 0.83 | 36.58 ± 4.11 |
| EA + EEGNet† / EA + TS-LR† | 68.52 ± 2.87 / 51.45 ± 0.00 | 48.69 ± 2.32 / 50.59 ± 0.00 | 44.67 ± 6.21 / 28.88 ± 0.00 |

Each entry is Macro-F1 (%) mean ± sample SD (ddof=1) over seeds 11, 22, 33 on fold 0.
BNCI/UCL each test one participant; EEGET tests one ALS participant plus its paired control.
† Uses unlabeled held-out trials. All checkpoint and threshold selection uses source validation only.
MAtt, SPDNet and TSMNet are reimplementations adapted to these datasets and the common trainer.
SPDIM-style adapts only the tangent-space SPD bias by fixed-step information maximization.
SD measures variation across seeds on this fold, not variation across participants.

UCL recovery: trials shorter than the configured two-second analysis window were excluded by a fixed sample-length rule. Counts by participant/class and all excluded trial IDs are saved under audit/UCL_eligibility_counts.csv and audit/UCL_excluded_short_trials.csv. BNCI and EEGET values reuse the original saved predictions; these models were not retrained.

EA + TS-LR: the original OAS/Riemannian pipeline is retained when numerically valid. On a numerical SPD failure, covariance eigenvalues are floored at 1e-6 times the larger of the trial maximum eigenvalue and the median source-training average variance. C and the decision threshold still use source validation only. Activation is recorded in each repaired result.
